# CHANGELOG.md — Sec Scanner Workspace

> **Версия:** 1.0.0
> **Тип:** Операционный документ — история развития Workspace
> **Владелец:** Engineering Manager
> **Статус:** Active (permanently active)

---

## Convention

Формат версионирования Workspace: **W.X.Y**

- **W (Major):** Фундаментальные изменения структуры (переименование каталогов, новая категория документов, изменение процесса)
- **X (Minor):** Новые документы, новые шаблоны, значительные обновления существующих файлов
- **Y (Patch):** Исправления ссылок, уточнения текста, мелкие правки

---

## [1.0.0] — 2026-07-15 — MIG-001: Documentation Migration & Knowledge Consolidation

### Добавлено

- **39 active документов** размещены в `docs/` структуре по 9 категориям
- **11 archived документов** с пометками Superseded by и причиной архивации
- INDEX.md обновлён до v2.0 с полным каталогом всех документов, строками, указателем по ролям

### Структура docs/

| Категория | Документов | Содержание |
|-----------|-----------|------------|
| 00_project_os | 4 | Конституция, Operating Model, Стандарты, Аудит |
| 01_strategy | 5 | PMF Blueprint, North Star, Gates, Multi-Channel, Intelligence |
| 02_architecture | 8 | Platform API, Audit, State Engine, Explainability, Contexts, Domain, Events, Dashboard |
| 03_product | 5 | Readiness, Maturity, Checklist, Beta Roadmap, First Value |
| 04_execution | 10 | Master Plan, Backlog, 4 Sprints, Milestones, Dependencies, Blockers, Dashboard |
| 05_growth | 5 | KPI, Growth Dashboard, Weekly/Monthly Templates, Experiments |
| 06_decisions | 2 | Decision Log, Decision Framework |
| 07_reviews | 0 | (пусто — первый review при Sprint 01) |
| 08_draft | 0 | (пусто) |
| archive | 11 | Superseded документы |

### Архивировано

- DOMAIN_MODEL.md → superseded by DOMAIN_MODEL_V2.md
- PRODUCT_ARCHITECTURE.md → superseded by PLATFORM_API_ARCHITECTURE.md
- ARCHITECTURE_AUDIT.md → superseded by PLATFORM_AUDIT.md
- ROADMAP_V2.md → superseded by PMF Blueprint §9
- REFACTOR_ROADMAP.md → superseded by PLATFORM_API_ARCHITECTURE.md Roadmap
- TECH_DEBT.md → superseded by PLATFORM_AUDIT.md Bottlenecks
- DEPENDENCY_GRAPH.md → superseded by PLATFORM_API_ARCHITECTURE.md
- USER_FLOW.md → superseded by PMF Blueprint §7
- FIRST_VALUE_AUDIT.md → superseded by FIRST_VALUE_EXPERIENCE.md
- PRODUCT_VISION_V2.md → superseded by PMF Blueprint
- SECURITY_STATE.md → superseded by SECURITY_STATE_ENGINE.md

### Ключевые решения миграции

1. **PRODUCT_VISION_V2 → Archive** (не консолидация). Уникальный контент (positioning comparison, ideal day, habit loop) уже полностью покрыт PMF Blueprint §1-4.
2. **SECURITY_STATE → Archive**. Product/design аспекты (visualization guidelines, gaming prevention) перекрыты DASHBOARD_V2. Implementation аспекты — в SECURITY_STATE_ENGINE.
3. **MULTI_CHANNEL_PRODUCT_STRATEGY → Active**. Уникальный стратегический анализ 5 каналов с ROI. Решение о Telegram Mini App (DECISION-009) уже зафиксировано.
4. **PRODUCT_MATURITY_SCORECARD → Active** (не консолидация с Readiness Report). Разные форматы: scorecard (матрица 12×4) vs narrative report (8-рольной self-check). Комплементарны.
5. **FIRST_VALUE_EXPERIENCE → Active** (не Archive). Хотя реализовано, содержит архитектурные решения (widget composition, demo data approach), полезные для будущих UI-задач.

### Устранено дублирование

- PERSONAS: 3 набора (USER_FLOW/PRODUCT_VISION_V2/PMF Blueprint) → 1 канонический (PMF Blueprint)
- SCORE ALGORITHMS: 3 источника (SECURITY_STATE/SECURITY_STATE_ENGINE/EXPLAINABILITY) → 1 (SECURITY_STATE_ENGINE)
- ARCHITECTURE AUDIT: 4 overlapping (PLATFORM_AUDIT/ARCHITECTURE_AUDIT/TECH_DEBT/PRODUCT_ARCHITECTURE) → 1 (PLATFORM_AUDIT)
- ROADMAP: 3 overlapping (ROADMAP_V2/REFACTOR_ROADMAP/PMF Blueprint §9) → 1 (PMF Blueprint)

### Причины

До MIG-001 все 50 документов находились в плоской директории `download/` без категоризации. REPO-001/002 создали структуру и навигацию, но документы физически не были перемещены. Цель MIG-001 — завершить Bootstrap: сделать все ссылки рабочими, устранить дублирование, создать реальный SSOT.

### Связанные задачи

MIG-001 (Documentation Migration & Knowledge Consolidation)

---

## [0.2.0] — 2026-07-15 — REPO-002: Production Readiness

### Добавлено

- **DECISION_LOG.md** (Workspace) — центральный каталог решений об инфраструктуре управления, отделённый от продуктового DECISION_LOG
- **CHANGELOG.md** — этот файл, история развития Workspace
- **INDEX.md** — навигационный центр документации
- **REPOSITORY_MAP.md** — визуальное описание структуры с Mermaid-диаграммами
- **DOCUMENT_LIFECYCLE.md** — формальная модель жизненного цикла документов (6 стадий, критерии переходов, правила архивирования)

### Изменено

- Определена концепция разделения ответственности: корневые `.md` = конфигурация Workspace, `docs/` = содержимое проекта
- Проведён перекрёстный аудит ссылок всех документов REPO-001
- Проведён Navigation Review с 4 перспектив (Founder, CTO, Developer, Auditor)

### Причины

REPO-001 прошёл CTO Review с высокой оценкой. Выявлены улучшения для Production Readiness: отсутствие навигационного центра, неформализованный жизненный цикл документов, отсутствие истории изменений Workspace. Цель — подготовить Workspace к MIG-001 (Documentation Migration).

### Связанные задачи

REPO-002 (Production Readiness)

---

## [0.1.0] — 2026-07-15 — REPO-001: Bootstrap GitHub Workspace

### Добавлено

- **README.md** — корпоративный entry point с обзором проекта, ролями, quick links
- **CONTRIBUTING.md** — правила работы с репозиторием (создание/изменение документов, ADR, Sprint, Roadmap, Git workflow)
- **REPOSITORY_STANDARDS.md** — стандарты организации репозитория (структура директорий, правила хранения, именование, архивирование)
- **GOVERNANCE.md** — управление репозиторием (классификация документов по методу обновления, RACI-матрица, Breaking Changes, Incident Response)
- **DEFINITIONS.md** — единая точка ссылки на DoR/DoD для 5 артефактов (Issue, ADR, Sprint, Review, Roadmap)
- **LABELS.md** — рекомендации по GitHub Labels (Priority, Type, Status, Area, Risk, Sprint, Gate)
- **MILESTONES_GUIDE.md** — карта GitHub Milestones к Success Gates (M1-M6)
- **GITHUB_PROJECTS.md** — конфигурация Kanban-доски (7 колонок, WIP limits, 5 views)
- **CODEOWNERS** — права обзора по директориям

### Добавлено (.github/)

- **6 Issue Templates:** Feature Request, Bug Report, Architecture Decision, Product Improvement, Technical Debt, Research
- **1 PR Template** с чеклистом валидации документов

### Определено (но не создано физически)

- Структура `docs/` с 9 каталогами (00-08 + archive)
- Распределение 30+ существующих документов по категориям
- Процесс Documentation Migration (MIG-001)

### Причины

Репозиторий `sec-scanner-workspace` на GitHub был пуст. Требовалось создать Workspace как Single Source of Truth для управления продуктом. Аудит показал: 30+ документов в плоской директории, отсутствие стандартов, дублирование, нет навигации.

### Связанные задачи

REPO-001 (Bootstrap GitHub Workspace)

### Предшествующий контекст

До REPO-001 все документы существовали в единой директории `download/` без категоризации. PROJECT_OS.md (TASK-012) создал концепцию «операционной системы проекта», но физическая структура не была реализована. REPO-001 реализовал эту концепцию в виде готового к git-репозиторию Workspace.

---

## Roadmap Workspace

| Версия | Задача | Содержание |
|--------|--------|------------|
| 0.1.0 | REPO-001 | Bootstrap: структура, шаблоны, governance |
| 0.2.0 | REPO-002 | Production Readiness: INDEX, Map, Lifecycle, CHANGELOG |
| **1.0.0** | **MIG-001** | **Documentation Migration: 39 active + 11 archived, все ссылки рабочие** |
| 1.1.0+ | — | Инкрементальные улучшения по мере использования |