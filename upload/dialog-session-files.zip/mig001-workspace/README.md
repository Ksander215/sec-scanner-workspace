# Sec Scanner Workspace

> **Единый источник правды** (Single Source of Truth) для управления развитием продукта Sec Scanner.

[![Project Stage: Pre-Alpha](https://img.shields.io/badge/Stage-Pre--Alpha-orange)](https://github.com/Ksander215/sec-scanner-workspace)
[![Product Maturity: 3.7/10](https://img.shields.io/badge/Maturity-3.7%2F10-red)](docs/03_product/PRODUCT_MATURITY_SCORECARD.md)
[![Docs: 30+](https://img.shields.io/badge/Documents-30%2B-blue)](#-document-architecture)

---

## Что это за репозиторий?

Это **рабочее пространство компании** — не код, а операционная система для разработки продукта. Здесь живут все стратегические документы, архитектурные решения, планы спринтов, метрики и регламенты.

Секция `docs/` содержит полную документацию проекта. Файлы в корне — конфигурация репозитория (шаблоны, стандарты, governance).

## Связь с основным продуктом

| Репозиторий | Назначение | Статус |
|------------|-----------|--------|
| **sec-scanner-workspace** (этот) | Документация, стратегия, процессы | Активный |
| sec-scanner (код) | Next.js 16 приложение, DAST engine | Развивается параллельно |

Продукт развёрнут на собственном VPS. Код продукта — в отдельном репозитории.

## Что такое Sec Scanner?

**DAST SaaS-платформа, которая переводит результаты сканирования уязвимостей на язык бизнес-метрик.**

- **Security Score (0-100)** — понятная метрика безопасности для CTO без security-экспертизы
- **Deterministic Explainability** — воспроизводимые объяснения уязвимостей (не AI-generated)
- **ROI-отсортированные рекомендации** — что исправить первым для максимального эффекта

**Целевая аудитория:** Startup (5-20 devs) и SMB (20-50 devs). Flat pricing от $29/мес.

**Tech Stack:** Next.js 16, React 19, Prisma 6, SQLite, next-auth v4, TanStack React Query, shadcn/ui.

Подробнее: [PROJECT_OS.md](docs/00_project_os/PROJECT_OS.md)

## Текущий этап

**Stage:** Pre-revenue, Architecture Complete, Pre-Beta.

Архитектурный фундамент готов (Clean Architecture, Domain Layer с 165 тестами). Продукт (DAST scanning) не реализован. Product Maturity: **3.7/10**.

**Следующий шаг:** Sprint 01 — Core Product Value (реальный DAST engine + Demo Target).

См. [FOUNDER_DASHBOARD.md](docs/04_execution/FOUNDER_DASHBOARD.md) для текущего статуса.

## Document Architecture

```
docs/
  00_project_os/          Конституция проекта, AI Operating Model, стандарты
  01_strategy/            PMF Blueprint, GTM, North Star, Success Gates
  02_architecture/        Platform API, Security State Engine, Explainability
  03_product/             Readiness, Checklist, Maturity, Beta Roadmap
  04_execution/           Master Plan, Backlog, Sprints, Milestones
  05_growth/              KPI Catalog, Dashboard, Reviews, Experiments
  06_decisions/           Decision Log, Decision Framework
  07_reviews/             Weekly и Monthly review артефакты
  08_draft/               Черновики и research (жизнь < 1 TASK)
  archive/                Исторические документы (superseded)
```

> **Progress:** `[===>          ]` Gate 0 / 5 -- Pre-Alpha, Sprint 01 not started
> **WASP:** 0 / 50 (M3 target)



### Новому участнику

1. **[README.md](README.md)** — вы читаете это (2 мин)
2. **[INDEX.md](INDEX.md)** — навигация по всем документам (3 мин)
3. **[PROJECT_OS.md](docs/00_project_os/PROJECT_OS.md)** — конституция проекта (30 мин)
4. **[AI_OPERATING_MODEL.md](docs/00_project_os/AI_OPERATING_MODEL.md)** — регламент разработки (20 мин)

### Быстрый статус

1. **[FOUNDER_DASHBOARD.md](docs/04_execution/FOUNDER_DASHBOARD.md)** — текущий статус (5 мин)
2. **[MASTER_EXECUTION_PLAN.md](docs/04_execution/MASTER_EXECUTION_PLAN.md)** — что строим и в каком порядке
3. **[EXECUTION_BACKLOG.md](docs/04_execution/EXECUTION_BACKLOG.md)** — все задачи с приоритетами

## Роли в проекте

| Роль | Зона ответственности | Решения |
|------|---------------------|---------|
| **Founder / CEO** | Человек | Стратегия, приоритеты, бюджет, инвесторы | Финальные (BDR, MDR) |
| **CTO** | Z.ai / ChatGPT | Архитектура, код, безопасность | Предлагает (ADR, SDR) |
| **CPO** | Z.ai / ChatGPT | Продукт, UX, roadmap, метрики | Предлагает (PDR, UDR) |
| **Engineering Manager** | Z.ai | Процессы, стандарты, документация | Операционные (ODR) |

## Жизненный цикл разработки

```
Idea -> Discussion -> Requirements -> Arch Review -> Planning -> Approved ->
Implementation -> Self Review -> CTO Review -> Testing -> Doc Update ->
Metrics -> Done -> Retrospective
```

Подробнее: [AI_OPERATING_MODEL.md](docs/00_project_os/AI_OPERATING_MODEL.md)

## Правила работы

- Все задачи проходят через **DoR** перед началом и **DoD** перед завершением
- **WIP = 1** — одна активная задача за раз
- Каждое значимое решение фиксируется в [DECISION_LOG.md](docs/06_decisions/DECISION_LOG.md)
- Все документы следуют [DOCUMENT_STANDARDS.md](docs/00_project_os/DOCUMENT_STANDARDS.md)

## North Star Metric

**WASP** (Weekly Active Scanning Projects) — количество уникальных проектов, отсканированных за последние 7 дней.

Текущий: **0**. Цель (M3): **50**. Цель (M12): **500**.

## Quick Links

| Документ | Назначение |
|---------|-----------|
| [Master Execution Plan](docs/04_execution/MASTER_EXECUTION_PLAN.md) | Что строить и в каком порядке |
| [Execution Backlog](docs/04_execution/EXECUTION_BACKLOG.md) | Все задачи с BV/EC/ROI |
| [Success Gates](docs/01_strategy/SUCCESS_GATES.md) | 6 контрольных точек развития |
| [KPI Catalog](docs/05_growth/KPI_CATALOG.md) | 28 метрик (AARRR + Product + Engineering + Business) |
| [Experiment Playbook](docs/05_growth/EXPERIMENT_PLAYBOOK.md) | Как проводить продуктовые эксперименты |

## Навигация по Workspace

| Документ | Назначение |
|---------|-----------|
| [INDEX.md](INDEX.md) | Полная навигация по документации, указатель по ролям |
| [REPOSITORY_MAP.md](REPOSITORY_MAP.md) | Визуальная карта репозитория (Mermaid) |
| [DOCUMENT_LIFECYCLE.md](DOCUMENT_LIFECYCLE.md) | Жизненный цикл документов (6 стадий) |
| [CHANGELOG.md](CHANGELOG.md) | История изменений Workspace |
| [DECISION_LOG.md](DECISION_LOG.md) | Решения об инфраструктуре управления |

---

*Подробности о структуре репозитория: [REPOSITORY_STANDARDS.md](REPOSITORY_STANDARDS.md)*
*Как вносить изменения: [CONTRIBUTING.md](CONTRIBUTING.md)*
*Governance и ответственность: [GOVERNANCE.md](GOVERNANCE.md)*
