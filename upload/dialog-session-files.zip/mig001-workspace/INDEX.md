# INDEX.md — Sec Scanner Workspace

> **Дата:** 2026-07-15
> **Версия:** 2.0
> **Тип:** Операционный документ — Навигационный центр документации
> **Владелец:** Engineering Manager
> **Статус:** Active
> **Связанные документы:** README.md, REPOSITORY_STANDARDS.md, PROJECT_OS.md

---

## Как пользоваться этим документом

**Цель INDEX.md** — ответить на вопрос «где найти нужную информацию?» за 2-3 минуты.

Если вы здесь впервые:
1. Прочитайте [README.md](README.md) — обзор проекта (2 мин)
2. Этот документ (INDEX.md) — навигация (3 мин)
3. Перейдите к нужному разделу ниже

---

## Архитектура навигации

Workspace имеет **три уровня входа**, каждый с чётким назначением:

| Уровень | Вопрос | Аудитория |
|---------|--------|-----------|
| README.md | «Что за проект и зачем я здесь?» | Любой, впервые открывший репозиторий |
| INDEX.md | «Где документ про X?» | Любой участник, ищущий конкретную информацию |
| docs/ | «Детали по теме X» | Работающий с конкретной областью |

---

## Корневые файлы (Конфигурация Workspace)

Эти файлы управляют тем, **как** работает Workspace. Они не содержат информации о продукте.

| Файл | Назначение |
|------|-----------|
| [README.md](README.md) | Entry point проекта |
| [CONTRIBUTING.md](CONTRIBUTING.md) | Как вносить изменения |
| [REPOSITORY_STANDARDS.md](REPOSITORY_STANDARDS.md) | Стандарты организации репозитория |
| [GOVERNANCE.md](GOVERNANCE.md) | Управление, ответственности, RACI |
| [DEFINITIONS.md](DEFINITIONS.md) | DoR/DoD для всех артефактов |
| [LABELS.md](LABELS.md) | GitHub Labels конфигурация |
| [MILESTONES_GUIDE.md](MILESTONES_GUIDE.md) | Milestones ↔ Success Gates |
| [GITHUB_PROJECTS.md](GITHUB_PROJECTS.md) | Kanban-доска конфигурация |
| [DECISION_LOG.md](DECISION_LOG.md) | Журнал решений Workspace (инфраструктура) |
| [CHANGELOG.md](CHANGELOG.md) | История изменений Workspace |
| [INDEX.md](INDEX.md) | Навигация (этот документ) |
| [REPOSITORY_MAP.md](REPOSITORY_MAP.md) | Визуальная карта структуры (Mermaid) |
| [DOCUMENT_LIFECYCLE.md](DOCUMENT_LIFECYCLE.md) | Жизненный цикл документов (6 стадий) |
| [CROSS_REFERENCE_AUDIT.md](CROSS_REFERENCE_AUDIT.md) | Отчёт о перекрёстном аудите (REPO-002) |
| [NAVIGATION_REVIEW.md](NAVIGATION_REVIEW.md) | Navigation Review + Self-Review (REPO-002) |

---

## docs/ — Содержание проекта

### `docs/00_project_os/` — Конституция проекта (4 документа)

**Назначение:** Фундаментальные документы, определяющие «как мы работаем». Читаются первыми при onboarding.

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [PROJECT_OS.md](docs/00_project_os/PROJECT_OS.md) | Конституция: Vision, Mission, принципы, стратегия, стек, роли, Document Index | 405 |
| [AI_OPERATING_MODEL.md](docs/00_project_os/AI_OPERATING_MODEL.md) | Регламент: Task Lifecycle (14 стадий), DoR/DoD, приоритизация, Release Lifecycle | 1117 |
| [DOCUMENT_STANDARDS.md](docs/00_project_os/DOCUMENT_STANDARDS.md) | Стандарты: метаданные, структура, версионирование, шаблон | 195 |
| [DOCUMENT_AUDIT.md](docs/00_project_os/DOCUMENT_AUDIT.md) | Инвентаризация: статус каждого документа, дублирование, рекомендации | 163 |

**Порядок чтения:** PROJECT_OS → AI_OPERATING_MODEL → DOCUMENT_STANDARDS
**Владелец:** Engineering Manager (PROJECT_OS, DOCUMENT_*), CTO (AI_OPERATING_MODEL)

---

### `docs/01_strategy/` — Стратегия и позиционирование (5 документов)

**Назначение:** Документы, отвечающие на «что мы строим и для кого». Изменяются редко (квартально или при pivot).

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [PRODUCT_MARKET_FIT_BLUEPRINT.md](docs/01_strategy/PRODUCT_MARKET_FIT_BLUEPRINT.md) | Полный PMF-анализ: 4 ключевых вопроса, ICP (5 сегментов), JTBD, конкурентный анализ (10 компаний), GTM, pricing, 90-дневный план | 1155 |
| [NORTH_STAR_METRIC.md](docs/01_strategy/NORTH_STAR_METRIC.md) | WASP: определение, обоснование, формула, leading indicators, guardrail metrics, прокси-метрики | 224 |
| [SUCCESS_GATES.md](docs/01_strategy/SUCCESS_GATES.md) | 6 контрольных точек: Gate 0 (Alpha) → Gate 5 (PMF Signal), критерии, метрики, риски | 250 |
| [MULTI_CHANNEL_PRODUCT_STRATEGY.md](docs/01_strategy/MULTI_CHANNEL_PRODUCT_STRATEGY.md) | Анализ 5 каналов: Web, Telegram Bot, Telegram Mini App, API, Mobile. ROI по каналам. Решение: Email Digest > Telegram Mini App | 845 |
| [PRODUCT_INTELLIGENCE_FRAMEWORK.md](docs/01_strategy/PRODUCT_INTELLIGENCE_FRAMEWORK.md) | Система Product Intelligence: Success Model, Decision by Data, Founder Cockpit, Governance | 349 |

**Порядок чтения:** PMF Blueprint → Success Gates → North Star → Multi-Channel → Intelligence Framework
**Владелец:** CEO (PMF Blueprint, Intelligence Framework), CPO (North Star, Success Gates, Multi-Channel)

---

### `docs/02_architecture/` — Техническая архитектура (8 документов)

**Назначение:** Архитектурные решения, модули, дизайн-документы. Implementation reference.

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [PLATFORM_API_ARCHITECTURE.md](docs/02_architecture/PLATFORM_API_ARCHITECTURE.md) | Platform Layer: Clean Architecture, Ports & Adapters, 7 application services, API versioning, multi-client support | 1567 |
| [PLATFORM_AUDIT.md](docs/02_architecture/PLATFORM_AUDIT.md) | Глубокий аудит: Domain 9/10, App 1/10, «Big Ball of Mud», все architecture leaks, bottlenecks | 516 |
| [SECURITY_STATE_ENGINE.md](docs/02_architecture/SECURITY_STATE_ENGINE.md) | Техническая документация модуля: алгоритмы Score/Risk/Trend/Confidence, 82 теста, extension points | 403 |
| [EXPLAINABILITY_LAYER.md](docs/02_architecture/EXPLAINABILITY_LAYER.md) | Архитектура: 4 типа объяснений (reasons, changes, recommendations, summaries), 83 теста | 321 |
| [BOUNDED_CONTEXTS.md](docs/02_architecture/BOUNDED_CONTEXTS.md) | DDD: 10 bounded contexts, границы, интерфейсы, события. Примечание: возможен over-engineering для текущего этапа | 598 |
| [DOMAIN_MODEL_V2.md](docs/02_architecture/DOMAIN_MODEL_V2.md) | Доменная модель v2: 20+ сущностей, Workspace→Project→Target→Finding, lifecycle | 774 |
| [EVENT_MODEL.md](docs/02_architecture/EVENT_MODEL.md) | Event-driven: 25+ event types, 3-tier transport (in-process → Redis → Kafka). Примечание: premature для текущего этапа | 694 |
| [DASHBOARD_V2.md](docs/02_architecture/DASHBOARD_V2.md) | Target-state UI spec: layout, 8 widgets, навигация, empty states, SSE, performance budget | 371 |

**Порядок чтения:** Platform API Architecture → Bounded Contexts → Domain Model → Security State Engine → Explainability → Dashboard V2 → Platform Audit → Event Model
**Владелец:** CTO

---

### `docs/03_product/` — Продукт и UX (5 документов)

**Назначение:** Оценка готовности, checklist'ы, roadmap до beta, реализованные features.

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [PRODUCT_READINESS_REPORT.md](docs/03_product/PRODUCT_READINESS_REPORT.md) | Комплексная оценка: 8-рольной self-check, user journey (8 стадий), TTFV, конкурентное сравнение | 423 |
| [PRODUCT_MATURITY_SCORECARD.md](docs/03_product/PRODUCT_MATURITY_SCORECARD.md) | 12-мерная оценка зрелости: 3.7/10 overall, trajectory (3.7→6.5→7.5) | 199 |
| [PRIVATE_BETA_CHECKLIST.md](docs/03_product/PRIVATE_BETA_CHECKLIST.md) | Beta launch checklist: 22 items (10 Blocking, 12 Nice-to-have) | 124 |
| [PRIVATE_BETA_ROADMAP.md](docs/03_product/PRIVATE_BETA_ROADMAP.md) | План до beta: 8 P0 + 5 P1 + 6 P2 задач, 2-3 недели | 265 |
| [FIRST_VALUE_EXPERIENCE.md](docs/03_product/FIRST_VALUE_EXPERIENCE.md) | Реализация: Security tab с demo data, ScoreGauge, RiskTrendCards, ExecutiveSummary | 173 |

**Порядок чтения:** Beta Checklist → Readiness Report → Maturity Scorecard → Beta Roadmap → First Value Experience
**Владелец:** CPO

---

### `docs/04_execution/` — Планирование и выполнение (10 документов)

**Назначение:** Что строим, в каком порядке, текущий статус. Самая часто обновляемая категория.

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [MASTER_EXECUTION_PLAN.md](docs/04_execution/MASTER_EXECUTION_PLAN.md) | Стратегический план: 4 спринта, 16 задач с BV/EC/ROI, Execution Rules | 169 |
| [EXECUTION_BACKLOG.md](docs/04_execution/EXECUTION_BACKLOG.md) | Все 25 задач: приоритеты, зависимости, KPI, статусы | 312 |
| [SPRINT_01.md](docs/04_execution/SPRINT_01.md) | Sprint 01: Core Product Value (EX-001..005) — Gate 0 | 70 |
| [SPRINT_02.md](docs/04_execution/SPRINT_02.md) | Sprint 02: Beta Readiness (EX-006..011) — Gate 0→1 | 75 |
| [SPRINT_03.md](docs/04_execution/SPRINT_03.md) | Sprint 03: Launch + First Users (EX-012..015) — Gate 1 | 70 |
| [SPRINT_04.md](docs/04_execution/SPRINT_04.md) | Sprint 04: Learn + Iterate (EX-016) — Gate 2 progress | 67 |
| [MILESTONES.md](docs/04_execution/MILESTONES.md) | 6 milestones: Alpha → Beta → 50 Users → First Paid → PMF Signal | 238 |
| [DEPENDENCY_MAP.md](docs/04_execution/DEPENDENCY_MAP.md) | Карта зависимостей: критический путь EX-002→006→012→014→016 | 111 |
| [BLOCKERS.md](docs/04_execution/BLOCKERS.md) | Активные блокеры: SMTP, DAST Scope, Demo Target, Landing Page | 84 |
| [FOUNDER_DASHBOARD.md](docs/04_execution/FOUNDER_DASHBOARD.md) | 5-минутный Dashboard: что/почему/блокеры/эффект/решения | 108 |

**Порядок чтения:** FOUNDER_DASHBOARD → MASTER_EXECUTION_PLAN → EXECUTION_BACKLOG → текущий SPRINT
**Владелец:** CTO (Sprints, Backlog, Dependencies, Blockers), CEO (Milestones, Dashboard)

---

### `docs/05_growth/` — Метрики и рост (5 документов)

**Назначение:** Система измерения: North Star, KPI, Reviews, эксперименты.

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [KPI_CATALOG.md](docs/05_growth/KPI_CATALOG.md) | 28 метрик: AARRR (15) + Product (4) + Engineering (4) + Business (5) | 439 |
| [GROWTH_DASHBOARD.md](docs/05_growth/GROWTH_DASHBOARD.md) | Шаблон дашборда: 5 уровней (Executive/Product/Engineering/Business/Growth) | 235 |
| [WEEKLY_REVIEW_TEMPLATE.md](docs/05_growth/WEEKLY_REVIEW_TEMPLATE.md) | Шаблон: Dashboard Update + 6 Key Questions + Gate Check + Experiments | 174 |
| [MONTHLY_BUSINESS_REVIEW.md](docs/05_growth/MONTHLY_BUSINESS_REVIEW.md) | Шаблон: 13 разделов (Product, Users, Engineering, Marketing, Finances, Debts, Experiments) | 341 |
| [EXPERIMENT_PLAYBOOK.md](docs/05_growth/EXPERIMENT_PLAYBOOK.md) | Процесс: гипотеза → test → decision, правила, примеры | 322 |

**Порядок чтения:** KPI Catalog → Growth Dashboard → Experiment Playbook → Weekly Template → Monthly Template
**Владелец:** CPO

---

### `docs/06_decisions/` — Корпоративная память (2 документа)

**Назначение:** Почему мы приняли те или иные решения. Решения никогда не удаляются.

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [DECISION_LOG.md](docs/06_decisions/DECISION_LOG.md) | 12 записей: стек, архитектура, ценообразование, GTM, операционные решения | 286 |
| [DECISION_MANAGEMENT_FRAMEWORK.md](docs/06_decisions/DECISION_MANAGEMENT_FRAMEWORK.md) | Система: таксономия (7 типов), lifecycle, метрики, knowledge graph | 1006 |

**Порядок чтения:** Decision Management Framework → DECISION_LOG (последние 3-5 решений)
**Владелец:** Любая роль (DECISION_LOG), Engineering Manager (Framework)

---

### `docs/07_reviews/` — Артефакты Review

**Назначение:** Результаты Weekly и Monthly Reviews. Создаются по шаблонам из `05_growth/`.

| Паттерн | Пример | Шаблон |
|---------|--------|--------|
| Weekly Review | `weekly-2026-07-21.md` | [WEEKLY_REVIEW_TEMPLATE.md](docs/05_growth/WEEKLY_REVIEW_TEMPLATE.md) |
| Monthly Review | `monthly-2026-07.md` | [MONTHLY_BUSINESS_REVIEW.md](docs/05_growth/MONTHLY_BUSINESS_REVIEW.md) |
| Experiment | `experiment-001-onboarding.md` | [EXPERIMENT_PLAYBOOK.md](docs/05_growth/EXPERIMENT_PLAYBOOK.md) |

**Статус:** 1 артефакт.

| Документ | Содержание | Строки |
|----------|-----------|--------|
| [MIGRATION_REPORT.md](docs/07_reviews/MIGRATION_REPORT.md) | Итоговый отчёт о миграции MIG-001: аудит, классификация, дедупликация, 4-role self-review | 280 |

---

### `docs/08_draft/` — Черновики

**Назначение:** Временные документы со сроком жизни < 1 TASK. Исследования, прототипы.

**Правила:** Draft без изменений > 2 TASK → ревью или архивация. Готовый → перемещение в категорию.

**Статус:** Пусто.

---

### `docs/archive/` — Архив (11 документов)

**Назначение:** Superseded и исторические документы. Сохраняют контекст, не используются для решений.

| Документ | Причина архивации | Superseded by |
|----------|-------------------|---------------|
| DOMAIN_MODEL.md | v1 доменной модели | [DOMAIN_MODEL_V2.md](docs/02_architecture/DOMAIN_MODEL_V2.md) |
| PRODUCT_ARCHITECTURE.md | v1 product architecture | [PLATFORM_API_ARCHITECTURE.md](docs/02_architecture/PLATFORM_API_ARCHITECTURE.md) |
| ARCHITECTURE_AUDIT.md | v1 audit, менее глубокий | [PLATFORM_AUDIT.md](docs/02_architecture/PLATFORM_AUDIT.md) |
| ROADMAP_V2.md | 12-month roadmap | [PRODUCT_MARKET_FIT_BLUEPRINT.md](docs/01_strategy/PRODUCT_MARKET_FIT_BLUEPRINT.md) §9 |
| REFACTOR_ROADMAP.md | 6-sprint refactoring plan | [PLATFORM_API_ARCHITECTURE.md](docs/02_architecture/PLATFORM_API_ARCHITECTURE.md) Roadmap |
| TECH_DEBT.md | 20 tech debt items | [PLATFORM_AUDIT.md](docs/02_architecture/PLATFORM_AUDIT.md) Bottlenecks |
| DEPENDENCY_GRAPH.md | Module dependency graphs | [PLATFORM_API_ARCHITECTURE.md](docs/02_architecture/PLATFORM_API_ARCHITECTURE.md) |
| USER_FLOW.md | User flow maps | [PRODUCT_MARKET_FIT_BLUEPRINT.md](docs/01_strategy/PRODUCT_MARKET_FIT_BLUEPRINT.md) §7 |
| FIRST_VALUE_AUDIT.md | Pre-implementation UX audit | [FIRST_VALUE_EXPERIENCE.md](docs/03_product/FIRST_VALUE_EXPERIENCE.md) |
| PRODUCT_VISION_V2.md | Vision v2, positioning/personas | [PRODUCT_MARKET_FIT_BLUEPRINT.md](docs/01_strategy/PRODUCT_MARKET_FIT_BLUEPRINT.md) |
| SECURITY_STATE.md | Central entity design | [SECURITY_STATE_ENGINE.md](docs/02_architecture/SECURITY_STATE_ENGINE.md) |

---

## Указатель по ролям

### Founder / CEO — быстрый статус (5 мин)

1. [FOUNDER_DASHBOARD.md](docs/04_execution/FOUNDER_DASHBOARD.md)
2. [MASTER_EXECUTION_PLAN.md](docs/04_execution/MASTER_EXECUTION_PLAN.md)
3. Последний [weekly review](docs/07_reviews/)

### CTO — перед задачей (20 мин)

1. [AI_OPERATING_MODEL.md](docs/00_project_os/AI_OPERATING_MODEL.md) — регламент
2. [PLATFORM_API_ARCHITECTURE.md](docs/02_architecture/PLATFORM_API_ARCHITECTURE.md) — архитектура
3. [DEFINITIONS.md](DEFINITIONS.md) — DoR/DoD

### Новый участник — onboarding (~75 мин)

1. [README.md](README.md) — 2 мин
2. [INDEX.md](INDEX.md) — 5 мин
3. [PROJECT_OS.md](docs/00_project_os/PROJECT_OS.md) — 30 мин
4. [AI_OPERATING_MODEL.md](docs/00_project_os/AI_OPERATING_MODEL.md) — 20 мин
5. [CONTRIBUTING.md](CONTRIBUTING.md) — 10 мин
6. [REPOSITORY_STANDARDS.md](REPOSITORY_STANDARDS.md) — 8 мин

### Внешний аудитор / инвестор (30 мин)

1. [README.md](README.md) — 2 мин
2. [PROJECT_OS.md](docs/00_project_os/PROJECT_OS.md) — 10 мин
3. [PRODUCT_MARKET_FIT_BLUEPRINT.md](docs/01_strategy/PRODUCT_MARKET_FIT_BLUEPRINT.md) — 10 мин
4. [FOUNDER_DASHBOARD.md](docs/04_execution/FOUNDER_DASHBOARD.md) — 5 мин
5. [PRODUCT_MATURITY_SCORECARD.md](docs/03_product/PRODUCT_MATURITY_SCORECARD.md) — 3 мин

---

## Статистика Workspace

| Показатель | Значение |
|-----------|----------|
| **Active документов** | 39 |
| **Archived документов** | 11 |
| **Корневых файлов** | 15 |
| **Шаблонов GitHub** | 7 |
| **Общий объём (active)** | ~15,000 строк |
| **Категорий docs/** | 9 (00-08 + archive) |
| **Пустых разделов** | 1 (08_draft) |